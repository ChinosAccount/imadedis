global.expect = require('chai').expect
global.Promise = require('bluebird')
