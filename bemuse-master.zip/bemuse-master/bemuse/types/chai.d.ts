declare var expect: (typeof import('chai'))['expect']
