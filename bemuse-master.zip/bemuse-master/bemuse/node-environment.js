require('dotenv').load()
require('ts-node/register/transpile-only')
global.Promise = require('bluebird')
