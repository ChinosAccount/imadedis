export function isChartPlayable(chart) {
  return chart.keys === '7K' || chart.keys === '5K'
}

export default isChartPlayable
