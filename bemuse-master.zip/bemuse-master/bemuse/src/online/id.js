export function id({ md5, playMode }) {
  return `${md5}-${playMode}`
}

export default id
