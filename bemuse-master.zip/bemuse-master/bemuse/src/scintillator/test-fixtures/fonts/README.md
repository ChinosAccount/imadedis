Example font from <https://github.com/GoodBoyDigital/pixi.js/tree/master/examples/example%2010%20-%20Text>

It is MIT licensed.
