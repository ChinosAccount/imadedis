import 'jquery'
import 'bemuse/bootstrap'
import FastClick from 'fastclick'
import React from 'react'

window.React = React
FastClick.attach(document.body)
