// !! avoid external dependencies since this is used in boot script!

import { Progress } from './Progress'
export default Progress
