var BemuseLogger: typeof import('./index')
