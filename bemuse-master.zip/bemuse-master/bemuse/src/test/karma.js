import 'bemuse/bootstrap'

import prepareTestEnvironment from './prepareTestEnvironment'
import loadSpecs from './loadSpecs'

prepareTestEnvironment()
loadSpecs()
