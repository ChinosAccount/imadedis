import createKeysoundCache from './createKeysoundCache'

export default createKeysoundCache()
