export default document.querySelector('#scene-root')
