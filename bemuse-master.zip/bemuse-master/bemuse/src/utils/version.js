/* eslint import/no-webpack-loader-syntax: off */
import version from 'val-loader!./version-loader'
export default version
