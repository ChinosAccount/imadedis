import gulp from 'gulp'

gulp.task('pre-commit', ['lint'])
